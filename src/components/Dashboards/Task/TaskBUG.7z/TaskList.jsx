"use client";
import { DndContext, closestCenter, useDroppable, DragOverlay } from '@dnd-kit/core';
import { SortableContext, verticalListSortingStrategy } from '@dnd-kit/sortable';
import Task from './Task';
import { useState, useEffect } from 'react';
import AddTask from './AddTask'; // Import AddTask component

export default function TaskList() {
    const [tasks, setTasks] = useState({
        todo: [],
        inProgress: [],
        done: [],
    });

    const [activeTask, setActiveTask] = useState(null); // Holds the currently dragged item

    // Fetch all tasks from the API when component mounts
    useEffect(() => {
        fetchAllTasks();
    }, []);

    const fetchAllTasks = async () => {
        try {
            const response = await fetch('http://localhost:5000/task/tasks');
            const data = await response.json();
            console.log(data);  // Log the fetched data

            const todoTasks = data?.filter((task) => task.tproces === 'todo');
            const inProgressTasks = data?.filter((task) => task.tproces === 'inprogress');
            const doneTasks = data?.filter((task) => task.tproces === 'done');

            const updatedTasks = {
                todo: todoTasks,
                inProgress: inProgressTasks,
                done: doneTasks,
            };

            setTasks(updatedTasks);  // Update the state

            // Log the updatedTasks instead of tasks to see the new value immediately
            console.log(updatedTasks);
        } catch (error) {
            console.error('Failed to fetch tasks:', error);
        }
    };

    useEffect(() => {
        console.log('Tasks have been updated:', tasks);
    }, [tasks]);



    const handleDragStart = (event) => {
        const { active } = event;
        const activeTask = getActiveTask(active.id);
        setActiveTask(activeTask);
    };

    const handleDragEnd = async (event) => {
        const { active, over } = event;
        setActiveTask(null); // Reset active task after drop

        if (!over) return; // If the task is dropped outside of a droppable area

        const activeContainer = getContainer(active.id);
        const overContainer = getContainer(over.id) || over.id; // fallback to container id

        if (activeContainer && overContainer && activeContainer !== overContainer) {
            // Moving between containers
            const activeIndex = tasks[activeContainer].findIndex((task) => task._id === active.id);
            const movedTask = tasks[activeContainer][activeIndex];

            // Update task status in MongoDB
            const updatedTask = { ...movedTask, tproces: overContainer };
            await updateTaskStatus(updatedTask);

            // Update task status locally in the state
            setTasks((prevTasks) => ({
                ...prevTasks,
                [activeContainer]: prevTasks[activeContainer].filter((task) => task._id !== active.id),
                [overContainer]: [...prevTasks[overContainer], updatedTask],
            }));
        }
    };

    const getContainer = (taskId) => {
        if (tasks.todo.find((task) => task._id === taskId)) return 'todo';
        if (tasks.inProgress.find((task) => task._id === taskId)) return 'inProgress';
        if (tasks.done.find((task) => task._id === taskId)) return 'done';
        return null; // In case the task is not found in any container
    };

    const getActiveTask = (taskId) => {
        return tasks.todo.find((task) => task._id === taskId) ||
            tasks.inProgress.find((task) => task._id === taskId) ||
            tasks.done.find((task) => task._id === taskId);
    };

    // Function to add a new task via the API
    const addTask = async (taskName) => {
        const newTask = {
            tname: taskName,
            tproces: 'todo',
            author: 'Foysal',
            tdate: '',
            ttime: '',
        };

        try {
            const response = await fetch('http://localhost:5000/task/tasks/add', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(newTask),
            });

            if (response.ok) {
                const addedTask = await response.json();
                setTasks((prevTasks) => ({
                    ...prevTasks,
                    todo: [...prevTasks.todo, addedTask], // Add the new task to the "todo" list
                }));
            }
        } catch (error) {
            console.error('Failed to add task:', error);
        }
    };

    // Function to update task status in the backend
    const updateTaskStatus = async (task) => {
        try {
            const response = await fetch(`http://localhost:3000/task/tasks/update/${task._id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(task),
            });
            console.log("Task Updated", task)

            if (!response.ok) {
                console.error('Failed to update task');
            }
        } catch (error) {
            console.error('Failed to update task:', error);
        }
    };

    return (
        <div className="p-6">
            {/* Use the AddTask component and pass addTask as a prop */}
            <AddTask addTask={addTask} />

            {/* Single DndContext wrapping all three columns */}
            <DndContext
                collisionDetection={closestCenter}
                onDragStart={handleDragStart}
                onDragEnd={handleDragEnd}
            >
                <div className="flex gap-6 justify-between">
                    {/* Todo Column */}
                    <DroppableColumn id="todo" tasks={tasks.todo} title="Todo" />

                    {/* In Progress Column */}
                    <DroppableColumn id="inProgress" tasks={tasks.inProgress} title="In Progress" />

                    {/* Done Column */}
                    <DroppableColumn id="done" tasks={tasks.done} title="Done" />
                </div>

                {/* DragOverlay for smoother drag */}
                <DragOverlay>
                    {activeTask ? <Task task={activeTask} /> : null}
                </DragOverlay>
            </DndContext>
        </div>
    );
}

function DroppableColumn({ id, tasks, title }) {
    const { setNodeRef } = useDroppable({
        id, // Unique id for each droppable area (todo, inProgress, done)
    });

    return (
        <div ref={setNodeRef} className="bg-gray-100 p-4 rounded-lg w-1/3 shadow min-h-[200px]">
            <h2 className="text-xl font-semibold text-center mb-4">{title}</h2>
            <SortableContext items={tasks.map((task) => task._id)} strategy={verticalListSortingStrategy}>
                <ul className="space-y-2 min-h-[100px]">
                    {tasks.length > 0 ? (
                        tasks.map((task) => <Task key={task._id} task={task} />)
                    ) : (
                        <div className="text-center text-gray-500">No tasks</div>
                    )}
                </ul>
            </SortableContext>
        </div>
    );
}
